function p = proj(u,lb,ub)

p = u;
p(p<lb) = lb;
p(p>ub) = ub;