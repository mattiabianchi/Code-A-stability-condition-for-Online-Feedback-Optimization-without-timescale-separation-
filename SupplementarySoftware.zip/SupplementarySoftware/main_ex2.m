clear
close all
clc

%% Definition of the dynamical system

A = [ 0 -0.1; 0.1 -0.1];
B = [0; 0.1];
Bw = [0.1; 0.1];
C = [1 1];

n = size(A,1);
m = size(B,2);
p = size(C,1);
q = size(Bw,2);


%% Definitions

% Define system functions
yref = 0;
uref = 0;

muPhi = 10.84;
f = @(x,u,w) A*x+B*u+B*sin(u)+Bw*w; 
h = @(u,w)  -C/A*(B*u+B*sin(u)+Bw*w);
nablah = @(u,w) -C/A*(B+B*cos(u));

%Cost 
Phi = @(u,y) muPhi*(u-uref)^2+ sqrt((y-yref)^2+1);
nablaPhi = @(u,y) [2*muPhi*(u-uref); (y-yref)/sqrt((y-yref)^2+1)];
nablauPhitilde = @(u,w)  [eye(m) nablah(u)']*nablaPhi(u,h(u,w));

%Constraints 
lb = -0.5e-4+uref;
ub = 0.5e-4+uref;


%% Setup simulation

omega =  1e-3*[-1 1 -1 1];
alpha = [1e-4 1e-2 1e-1 1e2];

nsim = length(alpha);
ndist = size(omega,2);

Tfin = 1000;
Delta = 1e-5; % Euler discretization stepsize
times = 0:Delta:Tfin;
kfin = length(times);
x0 = 0*rand(n,1);
u0 = 0*proj(rand(m,1),lb,ub);
ratio = 1e1;
ysim = zeros(p,ceil(kfin/ratio),nsim);
usim = zeros(m,ceil(kfin/ratio),nsim);
yopt = zeros(p,ceil(kfin/ratio),nsim);
uopt = zeros(m,ceil(kfin/ratio),nsim);

%% Perform simulation 

for i = 1:nsim

	x = zeros(n,kfin);
	u = zeros(m,kfin);
	d = zeros(q,kfin);
	x(:,1) = x0;
	u(:,1) = u0;

	for j = 1:ndist
		d(:,ceil((j-1)*(kfin/ndist))+1:ceil(j*kfin/ndist)) = omega(:,j)*ones(1,size(d(:,ceil((j-1)*(kfin/ndist))+1:ceil(j*kfin/ndist)),2));
		% Compute optimal solution
		uoptaux = rand(m,1);
		for l = 1:1e+5
            uoptaux = proj(uoptaux-1e-2*nablauPhitilde(uoptaux,omega(:,j)),lb,ub);
		end
		yoptaux = h(uoptaux,omega(:,j));
		yopt(:,ceil((j-1)/ratio*(kfin/ndist))+1:ceil(j/ratio*kfin/ndist),i) =  yoptaux*ones(1,size(yopt(:,ceil((j-1)/ratio*(kfin/ndist))+1:ceil(j/ratio*kfin/ndist),i),2));
        uopt(:,ceil((j-1)/ratio*(kfin/ndist))+1:ceil(j/ratio*kfin/ndist),i) =  uoptaux*ones(1,size(uopt(:,ceil((j-1)/ratio*(kfin/ndist))+1:ceil(j/ratio*kfin/ndist),i),2));
	end


	for k = 2:kfin
		x(:,k) = x(:,k-1)+Delta*f(x(:,k-1),u(:,k-1),d(:,k-1));
		u(:,k) = u(:,k-1)+ Delta*alpha(i)*(-u(:,k-1)+proj(u(:,k-1)-[eye(m) nablah(u(:,k-1),d(:,k-1))']*nablaPhi(u(:,k-1),C*x(:,k-1)),lb,ub));
	end
	ysim(:,:,i) = C*x(:,1:ratio:end);
	usim(:,:,i) = u(:,1:ratio:end);
end
	
%% Plot 
% save
figure
for i = 1:nsim
	plot(times(1:ratio:end),ysim(:,:,i))
	hold on
	plot(times(1:ratio:end),yopt(:,:,i),"b")
end
ylim(1e-4*[-10,10])

%%
figure
for i = 1:nsim
	plot(times(1:ratio:end),usim(:,:,i))
    hold on
end
